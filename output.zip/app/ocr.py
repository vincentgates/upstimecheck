import platform
import re
from datetime import datetime

import pytesseract
from PIL import Image, ImageEnhance

# On Windows, Tesseract isn't on PATH after install — point to it explicitly.
# On Linux (Heroku, etc.) it's installed via apt/buildpack and found on PATH automatically.
if platform.system() == 'Windows':
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# ── UPS app / handheld terminal regexes ──────────────────────────────────────
# \s* handles "Punchedout" (no space) — common OCR drop on photo-of-screen
_PUNCH_RE       = re.compile(r'Punched\s*(In|Out)[^\d]{0,10}(\d{1,2}:\d{2})', re.IGNORECASE)
_SCHED_RE       = re.compile(r'Sched(?:uled)?[^\d]{0,15}(\d{1,2}:\d{2})', re.IGNORECASE)
_DAILY_TOTAL_RE = re.compile(r'(?:Daily\s+)?Total[^\d]{0,20}(\d+):(\d{2})', re.IGNORECASE)

# ── UPS official weekly time system (UPS.com Microsoft portal) ────────────────
# Format per day block (worked day):
#   Tue 06/16/2026
#   Pay Code: Gross Pay:
#   PAY ACTUAL  132.53
#   Start Time: 4.17   Pay Rate: 0.00
#   End Time:   9.48   Total Hours: 5.31
#
# No Card (day off) block:
#   Sun 06/14/2026
#   Pay Code: Gross Pay:
#   No Card  0.00
#   Start Time: N/A  Pay Rate: 0.00
#   End Time:   N/A  Total Hours: 0.00
#
# Times are DECIMAL HOURS — 4.17 = 4h 10m (0.17 × 60).
# An asterisk on Start Time (e.g. "4.12*") is stored as corrected=True.
_OFF_DATE_RE     = re.compile(r'(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+(\d{2}/\d{2}/\d{4})', re.IGNORECASE)
_OFF_PAY_CODE_RE = re.compile(r'(PAY\s+ACTUAL|No\s+Card)\s+([\d.]+)', re.IGNORECASE)
_OFF_START_RE    = re.compile(r'Start\s+Time:\s*([\d.N/A]+)(\*)?', re.IGNORECASE)
_OFF_END_RE      = re.compile(r'End\s+Time:\s*([\d.N/A]+)', re.IGNORECASE)
_OFF_RATE_RE     = re.compile(r'Pay\s+Rate:\s*([\d.]+)', re.IGNORECASE)
_OFF_TOTAL_RE    = re.compile(r'Total\s+Hours:\s*([\d.]+)', re.IGNORECASE)

_EXIF_DATE_TAGS = (36867, 36868, 306)  # DateTimeOriginal, DateTimeDigitized, DateTime
_TARGET_WIDTH = 1600  # downsample to this before OCR — Tesseract chokes on 8K images


def extract_punches(image_path, source, fallback_date=None):
    """
    OCR a screenshot and return a list of punch dicts ready for DB insert.

    source='app'      — UPS handheld terminal photo; date from EXIF or fallback_date.
    source='official' — UPS weekly web portal screenshot; dates parsed from on-screen
                        text (multiple days per image). fallback_date is ignored.

    Returns [] if nothing useful could be parsed.
    """
    img = _preprocess(image_path, source)
    raw_text = pytesseract.image_to_string(img, config='--psm 6')
    confidence = _page_confidence(img)

    if source == 'official':
        return _parse_official_weekly(raw_text, confidence)

    punch_date = _exif_date(image_path) or fallback_date
    if punch_date is None:
        return []
    return _parse(raw_text, punch_date, confidence)


def _exif_date(image_path):
    """Return the date the photo was taken from EXIF, or None if unavailable."""
    try:
        exif = Image.open(image_path)._getexif()
        if exif:
            for tag_id in _EXIF_DATE_TAGS:
                val = exif.get(tag_id)
                if val:
                    return datetime.strptime(val, '%Y:%m:%d %H:%M:%S').date()
    except Exception:
        pass
    return None


def _preprocess(image_path, source='app'):
    img = Image.open(image_path)
    w, h = img.size
    if source == 'app':
        # Trim phone bezel and empty space below the EXIT button so the card
        # content fills the frame — critical for 8K phone photos of the terminal
        img = img.crop((int(w * 0.03), int(h * 0.08), int(w * 0.97), int(h * 0.75)))
    # Downscale wide images — Tesseract chokes on 8K+ widths
    if img.width > _TARGET_WIDTH:
        scale = _TARGET_WIDTH / img.width
        img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
    img = img.convert('L')
    return ImageEnhance.Contrast(img).enhance(1.5)


def _page_confidence(img):
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT,
                                     config='--psm 6')
    scores = [int(c) for c in data['conf'] if str(c) != '-1']
    return round(sum(scores) / len(scores) / 100, 3) if scores else 0.0


def _parse(raw_text, punch_date, confidence):
    """
    Parse raw OCR text from a UPS "Punch Out Summary" screen.

    Returns a list with at most one dict (one record per day).
    punch_in / punch_out may be None if the OCR missed one direction.
    scheduled_time and daily_total_minutes may be None if not visible.
    """
    scheduled_time = _parse_scheduled(raw_text)
    daily_total_minutes = _parse_daily_total(raw_text)

    punch_in = None
    punch_out = None
    for match in _PUNCH_RE.finditer(raw_text):
        direction, time_str = match.groups()
        t = datetime.strptime(time_str, '%H:%M').time()
        if direction.lower() == 'in':
            punch_in = t
        else:
            punch_out = t

    if punch_in is None and punch_out is None:
        return []

    return [{
        'date':                punch_date,
        'punch_in':            punch_in,
        'punch_out':           punch_out,
        'raw_ocr_text':        raw_text,
        'confidence':          confidence,
        'scheduled_time':      scheduled_time,
        'daily_total_minutes': daily_total_minutes,
    }]


def _parse_scheduled(raw_text):
    m = _SCHED_RE.search(raw_text)
    if m:
        return datetime.strptime(m.group(1), '%H:%M').time()
    return None


def _parse_daily_total(raw_text):
    m = _DAILY_TOTAL_RE.search(raw_text)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))
    return None


# ── Official weekly portal parser ─────────────────────────────────────────────

def _decimal_hours_to_time(val_str):
    """Convert decimal-hours string (e.g. '4.17') to datetime.time.
    UPS portal stores times as decimal hours: 4.17 = 4h 10.2m → 04:10.
    """
    val = float(str(val_str).rstrip('*').strip())
    hours = int(val)
    minutes = round((val - hours) * 60)
    if minutes >= 60:
        hours += 1
        minutes -= 60
    return datetime.strptime(f'{hours:02d}:{minutes:02d}', '%H:%M').time()


def _parse_official_weekly(raw_text, confidence):
    """
    Parse the UPS official weekly time system (UPS.com Microsoft portal).

    Every calendar day in the screenshot is returned — both worked days
    (pay_code='PAY ACTUAL') and days off (pay_code='No Card').
    No Card days have null punch_in / punch_out and 0 daily_total_minutes.

    corrected=True when the official system asterisked the start time
    (footnote: '*Indicates late for that day').
    """
    records = []

    blocks = re.split(
        r'(?=(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+\d{2}/\d{2}/\d{4})',
        raw_text, flags=re.IGNORECASE
    )

    for block in blocks:
        date_m = _OFF_DATE_RE.search(block)
        if not date_m:
            continue

        try:
            punch_date = datetime.strptime(date_m.group(1), '%m/%d/%Y').date()
        except ValueError:
            continue

        pay_code_m = _OFF_PAY_CODE_RE.search(block)
        if not pay_code_m:
            continue

        pay_code  = re.sub(r'\s+', ' ', pay_code_m.group(1).strip())  # normalise spacing
        gross_pay = _safe_float(pay_code_m.group(2))

        rate_m  = _OFF_RATE_RE.search(block)
        pay_rate = _safe_float(rate_m.group(1)) if rate_m else None

        total_m = _OFF_TOTAL_RE.search(block)
        daily_total_minutes = None
        if total_m:
            v = _safe_float(total_m.group(1))
            daily_total_minutes = round(v * 60) if v is not None else None

        if pay_code.upper() == 'NO CARD':
            records.append({
                'date':                punch_date,
                'pay_code':            'No Card',
                'gross_pay':           gross_pay,
                'punch_in':            None,
                'punch_out':           None,
                'pay_rate':            pay_rate,
                'daily_total_minutes': daily_total_minutes if daily_total_minutes is not None else 0,
                'corrected':           False,
                'raw_ocr_text':        block.strip(),
                'confidence':          confidence,
            })
            continue

        # Worked day — extract times
        start_m = _OFF_START_RE.search(block)
        end_m   = _OFF_END_RE.search(block)

        if not start_m or not end_m:
            continue

        corrected  = bool(start_m.group(2))
        start_val  = start_m.group(1).strip()
        end_val    = end_m.group(1).strip()

        if start_val in ('N/A', 'N', 'A') or end_val in ('N/A', 'N', 'A'):
            continue  # PAY ACTUAL row but times are N/A — skip

        try:
            punch_in  = _decimal_hours_to_time(start_val)
            punch_out = _decimal_hours_to_time(end_val)
        except (ValueError, AttributeError):
            continue

        records.append({
            'date':                punch_date,
            'pay_code':            'PAY ACTUAL',
            'gross_pay':           gross_pay,
            'punch_in':            punch_in,
            'punch_out':           punch_out,
            'pay_rate':            pay_rate,
            'daily_total_minutes': daily_total_minutes,
            'corrected':           corrected,
            'raw_ocr_text':        block.strip(),
            'confidence':          confidence,
        })

    return records


def _safe_float(val):
    try:
        return float(val)
    except (TypeError, ValueError):
        return None
